package com.example.applicationEA2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.IntentFilter;
import android.content.Intent;
import android.os.BatteryManager;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
private TextView mBateria;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBateria=(TextView) findViewById(R.id.bateria);

        if(!isOnline()){
            Toast.makeText(this.getApplicationContext(),"No hay conexión a internet", Toast.LENGTH_LONG).show();
        }
         
        Button botonlogin = findViewById(R.id.login);
        botonlogin.setOnClickListener(new LogInOnClickListener(this)); //componente que escucha al widget del boton login

        Button botonregistro = findViewById(R.id.registro);
        botonregistro.setOnClickListener(new RegisterOnClickListenerTo(this)); //componente que escucha al widget del boton registro

        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, ifilter);
        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        float batteryPct = level * 100 / (float)scale;
        mBateria.setText("Bateria: "+Float.toString(batteryPct)+ "%");

    }
    public boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }
}
