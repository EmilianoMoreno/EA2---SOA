package com.example.applicationEA2;

public class EventsResponse {

    private Boolean success;
    private String env;
    private EntidadResponse event;

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public EntidadResponse getEvent() {
        return event;
    }

    public void setEvent(EntidadResponse event) {
        this.event = event;
    }

    @Override
    public String toString() {
        return "EventsResponse{" +
                "success='" + success + '\'' +
                ", env='" + env + '\'' +
                ", event=" + event +
                '}';
    }
}
