package com.example.applicationEA2;

public class RegistroResponse {
    private Boolean success;
    private String env;
    private String token;
    private String token_refresh;
    private EntidadRegistro user;

    public Boolean getSuccess() { return success; }

    public void setSuccess(Boolean success) { this.success = success; }

    public String getToken_refresh() {
        return token_refresh;
    }

    public void setToken_refresh(String token_refresh) {
        this.token_refresh = token_refresh;
    }

    public EntidadRegistro getUser() {
        return user;
    }

    public void setUser(EntidadRegistro user) {
        this.user = user;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "RegistroResponse{" +
                "success='" + success + '\'' +
                ", env='" + env + '\'' +
                ", token='" + token + '\'' +
                ", token='" + token_refresh + '\'' +
                ", user=" + user +
                '}';
    }
}
